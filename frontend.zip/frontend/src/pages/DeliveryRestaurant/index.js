import DeliveryRestaurantPage from "./DeliveryRestaurantPage";
export default DeliveryRestaurantPage;
