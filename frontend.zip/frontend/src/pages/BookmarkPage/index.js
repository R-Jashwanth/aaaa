import BookmarkPage from "./BookmarkPage";
export default BookmarkPage;
