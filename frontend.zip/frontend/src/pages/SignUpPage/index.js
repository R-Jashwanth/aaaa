import SignUpPage from "./SignUpPage";
export default SignUpPage;
